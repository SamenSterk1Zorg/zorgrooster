export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>SamenSterk1Zorg Zorgrooster App komt hier</h1>
      <p>De app is nog in opbouw. Binnenkort verschijnt hier jouw rooster!</p>
    </div>
  );
}
